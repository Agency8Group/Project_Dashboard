import feedparser
import pandas as pd
from datetime import datetime, timedelta
import urllib.parse
from bs4 import BeautifulSoup
import logging
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO

# ===== 설정 =====
logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')

today = datetime.now().date()
week_ago = today - timedelta(days=1)

KEYWORDS = ["아이베", "eibe", "드리미", "dreame", "압타밀", "Aptamil", "누트리시아", "Nutricia", "로보락", "roborock", "매트리스"]

# ===== 한글 폰트 설정 =====
plt.rcParams['font.family'] = 'Malgun Gothic'  # 윈도우 기준
plt.rcParams['axes.unicode_minus'] = False

# ===== 뉴스 수집 함수 =====
def crawl_google_news(keyword):
    results = []
    encoded = urllib.parse.quote(keyword)
    rss_url = f"https://news.google.com/rss/search?q={encoded}&hl=ko&gl=KR&ceid=KR:ko"
    feed = feedparser.parse(rss_url)

    if feed.bozo:
        logging.warning(f"RSS parsing error occurred, keyword: {keyword}")

    for entry in feed.entries:
        try:
            if not hasattr(entry, "published_parsed"):
                logging.warning(f"No posting date information, skipped: {entry.title}")
                continue
            published_date = datetime(*entry.published_parsed[:3]).date()
        except Exception as e:
            logging.warning(f"Date parsing failed: {e}")
            continue

        if week_ago <= published_date <= today:
            raw_summary = entry.get("summary", "")
            soup = BeautifulSoup(raw_summary, "html.parser")

            media_tag = soup.find("font")
            if media_tag:
                media = media_tag.get_text(strip=True)
            elif hasattr(entry, 'source') and 'title' in entry.source:
                media = entry.source['title']
            else:
                media = ""

            results.append({
                "기사등록일": published_date.strftime("%Y-%m-%d"),
                "언론사": media,
                "키워드": keyword,
                "제목": entry.title.strip(),
                "링크": entry.link,
                "출처": "Google News RSS"
            })

    return results

# ===== 차트 생성 함수 =====
def create_chart_image(df, group_col, title, subtitle=""):
    plt.figure(figsize=(10, 6))
    # 세련된 색상 팔레트 예시 (파스텔톤 그라데이션)
    palette = sns.color_palette("crest", n_colors=len(df[group_col].unique()))

    ax = sns.countplot(data=df, x=group_col, order=df[group_col].value_counts().index, palette=palette)

    # 배경 제거 및 스타일 정리
    ax.set_facecolor('none')
    plt.gca().patch.set_alpha(0)  # 배경 투명화

    # 제목 및 부제목 꾸미기
    full_title = f"{title}\n{subtitle}" if subtitle else title
    ax.set_title(full_title, fontsize=18, fontweight='bold', color='#333333', pad=15, loc='center')

    # 축 라벨 및 눈금 최소화
    ax.set_xlabel("항목")
    ax.set_ylabel("기사 수", fontsize=14, color='#555555')
    ax.tick_params(axis='x', labelsize=12, rotation=15, colors='#666666')
    ax.tick_params(axis='y', labelsize=12, colors='#666666')

    # 값 표시 추가 (막대 위에 숫자)
    for p in ax.patches:
        height = p.get_height()
        ax.annotate(f'{height}', (p.get_x() + p.get_width() / 2., height),
                    ha='center', va='bottom', fontsize=11, color='#444444', fontweight='semibold')

    sns.despine(left=True, bottom=True)  # 축 테두리 깔끔하게 제거

    plt.tight_layout()

    buf = BytesIO()
    plt.savefig(buf, format="png", dpi=150, transparent=True)  # 투명 배경 저장
    plt.close()
    buf.seek(0)
    return buf

# ===== 메인 함수 =====
def main():
    all_results = []
    for keyword in KEYWORDS:
        logging.info(f"Searching Google News: {keyword}")
        all_results.extend(crawl_google_news(keyword))

    if not all_results:
        logging.info("No search results.")
        return

    df = pd.DataFrame(all_results)

    # 중복 제거 (제목 + 언론사 기준)
    df_before = len(df)
    df.drop_duplicates(subset=["제목", "언론사"], inplace=True)
    df_after = len(df)
    logging.info(f"중복 제거 전: {df_before}건 → 제거 후: {df_after}건")

    # 컬럼 순서 정리
    columns_order = ["기사등록일", "언론사", "키워드", "제목", "링크"]
    df = df[columns_order]

    # 저장할 파일 이름
    filename = f"news_{week_ago.strftime('%Y%m%d')}_to_{today.strftime('%Y%m%d')}.xlsx"
    writer = pd.ExcelWriter(filename, engine="xlsxwriter")

    # 시트 1: 뉴스 목록
    df.to_excel(writer, index=False, sheet_name="뉴스 목록")

    # 시트 2: 키워드 요약 + 차트
    keyword_summary = df["키워드"].value_counts().reset_index()
    keyword_summary.columns = ["키워드", "기사 수"]

    # 가로 정렬을 위해 transpose 형태로 변경
    keyword_summary_horizontal = pd.DataFrame([keyword_summary["기사 수"].values], columns=keyword_summary["키워드"].values)
    keyword_summary_horizontal.index = ["기사 수"]

    # 엑셀에 가로 테이블 작성 (A1부터)
    keyword_summary_horizontal.to_excel(writer, sheet_name="키워드 요약", startrow=0, startcol=0)

    workbook = writer.book
    sheet = writer.sheets["키워드 요약"]

    # 행 높이, 컬럼 너비 조절
    sheet.set_row(0, 30)  # 헤더 행 높이
    for col in range(len(keyword_summary_horizontal.columns)):
        sheet.set_column(col + 1, col + 1, 15)  # 키워드 컬럼 너비

    # 헤더 서식 (키워드)
    header_format = workbook.add_format({
        "bold": True,
        "text_wrap": True,
        "valign": "vcenter",
        "fg_color": "#D7E4BC",
        "border": 0
    })

    # 값 서식 (기사 수)
    cell_format = workbook.add_format({
        "border": 0,
        "valign": "vcenter",
        "align": "center"
    })

    # 헤더에 서식 적용 (1행, B1부터)
    for col_num in range(len(keyword_summary_horizontal.columns)):
        sheet.write(0, col_num + 1, keyword_summary_horizontal.columns[col_num], header_format)

    # 데이터에 서식 적용 (2행, B2부터)
    for col_num in range(len(keyword_summary_horizontal.columns)):
        sheet.write(1, col_num + 1, keyword_summary_horizontal.iloc[0, col_num], cell_format)

    # 행 인덱스 '기사 수'도 A2 셀에 써줌
    sheet.write(1, 0, keyword_summary_horizontal.index[0], cell_format)

    # 차트 이미지 삽입 (K2 셀 기준)
    subtitle = f"({week_ago.strftime('%Y-%m-%d')} ~ {today.strftime('%Y-%m-%d')})"
    chart_buf = create_chart_image(df, "키워드", "키워드별 기사 수", subtitle)
    sheet.insert_image("K2", "chart.png", {"image_data": chart_buf, "x_scale": 1.1, "y_scale": 1.1})

    writer.close()
    logging.info(f"완료: {filename}에 저장됨. 총 {len(df)}건 (중복 제거 포함)")

if __name__ == "__main__":
    main()
